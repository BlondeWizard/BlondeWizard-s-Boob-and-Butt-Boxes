****************************BlondeWizards Boob and Butt Boxes*****************************************


****Note! This was made in Blender 2.83, previous versions may or may not work****

****      Requirements     ****


Your Model must have a mesh.
Your Model must have Boobs and/or Butt bones to apply the bone parenting.



******    How to use     ******

- Open your desired model that has breasts and/or a butt.
- Move the Boob Box left and Boob Box Right over the corresponding breasts, make sure that the box
forms a bubble around the boob or glute, it needs to surround most of it, the vertex side or
the flat-faced side needs to be facing the base of the mesh, you can scale, rotate, transform, etc.
each box to your liking.

- Once a Box is positioned in the spot you want the bounce or physics to take place on your mesh,
click on your Model in Object Mode and add a Mesh Deform Modifier in the Modifiers Section.
- In the Mesh deform modifier, click on the Object section and pick the desired Box for the Binding
to take place.
- Click Bind, this will clamp the box to the Mesh and the Boob or Glute will jiggle around in the
Box.

- After Binding a Box to a part of the Mesh, click the BOX FIRST in object mode, then shift+click on
 the bone associated with that Boxes position, with the BOX and the BONE selected, click pose mode.
- Once you are in Pose mode, Mouse over to Pose > Parent > Bone
- Click Bone and now the BOX will follow the BONE wherever the Model goes.

- Aaaand your Done!


**Note: I cant figure out how to interact with the boxes in realtime in the viewport, so hit play 
on the timeline below and watch the jiggle effect on the boxes. You can play around with them 
adjust each one to your liking. Enjoy.**



****FAQ***
Can the Boxes collide with other Boxes, Objects, Dicks, Balls, etc.  ---Yes! they can, just add a
collision modifier to the selected Box for the Bound Mesh area and adjust settings accordingly.

***Credits***

Melt Rib on youtube for this video on how to setup the boxes: 
    
https://www.youtube.com/watch?v=P6Czt6BBsoQ&feature=youtu.be




mavixtiuos for the Blender porting of His Scarlet FFVII Model,  Link:

https://twitter.com/mavixtious?lang=en




Mustard over at Smutbase for making the Scarlet_V2 Model accessible for everyone.

https://smutba.se/user/10157/



I am still new to Blender and i cant offer too much but maybe we can learn from each other. Thanks!

If you have questions Contact me on Discord via:        BlondeWizard#7697





